# -*- coding: utf-8 -*-
import numpy as np, pandas as pd
from sklearn.preprocessing import StandardScaler

from dk_core import (
    build_feature_pathway_matrix,
    build_deepkegg_model_from_concat,
)

def _concat_omics(d):
    mats = [v for v in d.values() if v is not None]
    if not mats:
        raise ValueError("没有可用组学矩阵")
    common = set(mats[0].index)
    for m in mats[1:]:
        common &= set(m.index)
    if not common:
        raise ValueError("多组学样本交集为空")
    common = sorted(common)
    mats = [m.loc[common] for m in mats]
    X = pd.concat(mats, axis=1)
    return X

def _align_train_test(Xtr, Xte):
    cols = Xtr.columns.intersection(Xte.columns)
    return Xtr[cols].copy(), Xte[cols].copy()


def fit_one_fold_and_predict(train_dict, y_train, test_dict,
                             gmt_path=None, map_path=None,
                             k=64, r=1e-4, epochs=50, seed=42):
    """
    train_dict/test_dict: dict[str, DataFrame] 行=sample_id, 列=特征
    y_train: Series(index=sample_id) in {0,1}
    返回：按 test 任一模态的 index 顺序排列的概率(np.ndarray)
    """
    import tensorflow as tf
    from dk_core import build_deepkegg_model

    # --------------- 1) 严格对齐样本 ---------------
    present = {m for m in ["mRNA","miRNA","SNV"] if m in train_dict and m in test_dict}
    if not present:
        raise ValueError("no common modal in train/test")
    # train 交集（必须同时在所有 present 模态与 y 中）
    train_ids = set(y_train.index)
    for m in present:
        train_ids &= set(train_dict[m].index)
    train_ids = sorted(train_ids)
    if len(train_ids) == 0:
        raise ValueError("empty train intersection")
    # test 的顺序以第一个模态为准（step3 已保证一致）
    first = next(iter(present))
    test_ids = list(test_dict[first].index)

    # --------------- 2) 每模态做标准化（折内） ---------------
    x_train_list, x_test_list = [], []
    input_dims_present = {}
    for m in present:
        Xtr = train_dict[m].loc[train_ids].values.astype("float32")
        Xte = test_dict[m].loc[test_ids].values.astype("float32")
        scaler = StandardScaler(with_mean=True, with_std=True)
        Xtr = scaler.fit_transform(Xtr)
        Xte = scaler.transform(Xte)
        x_train_list.append(Xtr)
        x_test_list.append(Xte)
        input_dims_present[m] = Xtr.shape[1]

    y = y_train.loc[train_ids].astype(int).values.reshape(-1, 1)

    # --------------- 3) 构建并训练模型 ---------------
    tf.random.set_seed(seed)
    np.random.seed(seed)
    model, order = build_deepkegg_model(input_dims_present=input_dims_present,
                                        k=k, r=r, use_attention=False)
    # 重新按 order 排列输入列表
    order_idx = [list(present).index(m) for m in order]
    x_train_seq = [x_train_list[i] for i in order_idx]
    x_test_seq  = [x_test_list[i]  for i in order_idx]

    hist = model.fit(x_train_seq, y,
                     epochs=epochs, batch_size=32, verbose=0)

    # 可选：训练收敛性检查（首末 loss）
    try:
        l0 = float(hist.history["loss"][0]); lN = float(hist.history["loss"][-1])
        if not (lN < l0):
            print(f"[WARN] loss did not decrease: {l0:.4f} -> {lN:.4f}")
    except Exception:
        pass

    # --------------- 4) 预测（展平为 1D） ---------------
    y_prob = model.predict(x_test_seq, batch_size=256, verbose=0).reshape(-1)
    # 若依然接近常数，提醒一下
    if np.std(y_prob) < 1e-4:
        print("[WARN] predictions are ~constant; check data/labels/graph.")

    return y_prob
